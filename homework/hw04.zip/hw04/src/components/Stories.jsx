import React from "react";

export default function Stories({ token }) {
    return (
        <header className="flex gap-6 bg-white border p-2 overflow-hidden mb-6">
            Stories go here. Fetch data from /api/stories
        </header>
    );
}
