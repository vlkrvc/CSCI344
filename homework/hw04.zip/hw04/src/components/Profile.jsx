import React from "react";

export default function Profile({ token }) {
    return (
        <header className="flex gap-4 items-center">
            <p>Profile Goes Here. Fetch data from /api/profile/ endpoint.</p>
        </header>
    );
}
