# README.md

## Installation
On your terminal, navigate to your `csci/homework/hw03` folder, and run the following command:

```
npm install
```

## Build Stylesheet
After installing the Tailwind dependencies, run the following command from the terminal so that Tailwind continuously compiles your Tailwind stylesheet based on the changes you make in the HTML and CSS files:

```sh
npm run build:tailwind
```