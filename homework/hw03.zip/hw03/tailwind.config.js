module.exports = {
    content: ["./*html", "./js/*js"],
    theme: {
        fontFamily: {
            Comfortaa: ["Comfortaa"],
        },
    },
    plugins: [],
};
